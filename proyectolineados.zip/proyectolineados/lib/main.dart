import 'package:flutter/material.dart';
import 'package:proyectolineados/Vista/Geocalizacion.dart';
import 'package:proyectolineados/Vista/Login.dart';
import 'package:proyectolineados/Vista/moneda.dart';
import 'package:proyectolineados/Vista/rest.dart';
import 'package:proyectolineados/Vista/Registro.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:proyectolineados/Vista/Web.dart';
import 'firebase_options.dart';

void main() async{
 WidgetsFlutterBinding.ensureInitialized();
 await Firebase.initializeApp(
   options: DefaultFirebaseOptions.currentPlatform,);
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(debugShowCheckedModeBanner: false,
      home: Home(),
    );
  }
}

class Home extends StatefulWidget {
  @override
  HomeStart createState() => HomeStart();
}

class HomeStart extends State<Home>{
  Widget build(BuildContext context){
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Proyecto Linea De Profundizacion II',
      theme: ThemeData(primarySwatch: Colors.green),
      /*home: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage('imagenes/img.png'),
              fit: BoxFit.cover
          ),
        ),
      ), */
      home: Scaffold(
        appBar: AppBar(
          title: Text('Proyecto Linea II'),
          backgroundColor: Colors.green,
        ),
        body: SingleChildScrollView(
          //Osea que puede crecer verticalmente tanto como lo necesite
          child: Column(
            //Creamos una unica columna, por es se ve centrado
            //Con una seria de componentes dentro de un Array
            children: [
              Padding(padding: EdgeInsets.all(20),
                //La imagen iria centrada
                child: Center(
                  child: Container(
                    //Nos permite crear un contenedor para poner la imagen y configurar el tamaño que queramos
                    width: 350,
                    height: 300,
                    child: Image.asset('imagenes/img.png'),
                  ),
                ),
              ),
              //El padding tiene caracteristicas de centrado
              Padding(padding: EdgeInsets.only(left: 20, top: 10, right: 10),
                child: Center(
                  child: ElevatedButton(
                    onPressed: (){
                      print('Boton Entrar Presionado');
                      // El materialpageroute sirve para direccionar la pagina que necesitamos
                      Navigator.push(context, MaterialPageRoute(builder: (_)=> Login()) );
                      theme: ThemeData(primarySwatch: Colors.blue);
                    },
                    child: Text('Entrar', style: TextStyle(color: Colors.white, fontSize: 22)),
                  ),
                ),
              ),
              Padding (padding: EdgeInsets.only(left: 20, top: 30, right: 10),
                child: Center(
                  child: ElevatedButton(
                    onPressed: (){
                      print('Boton Registrar Presionado');
                      // El materialpageroute sirve para direccionar la pagina que necesitamos
                      Navigator.push(context, MaterialPageRoute(builder: (_)=> Registro()) );
                    },
                    child: Text('Registrar', style: TextStyle(color: Colors.white, fontSize: 20),
                  ),
                ),
              ),
              ),
        Padding (padding: EdgeInsets.only(left: 20, top: 30, right: 10),
          child: Center(
            child: ElevatedButton(
              onPressed: (){
                print('Boton De Geocalizacion Presionado');
                // El materialpageroute sirve para direccionar la pagina que necesitamos
                Navigator.push(context, MaterialPageRoute(builder: (_)=> Geocalizacion()) );
              },
              child: Text('Geocalizacion', style: TextStyle(color: Colors.white, fontSize: 20),
                     ),
              ),
               ),
             ),
              Padding (padding: EdgeInsets.only(left: 20, top: 30, right: 10),
                child: Center(
                  child: ElevatedButton(
                    onPressed: (){
                      print('Boton De Geocalizacion Presionado');
                      // El materialpageroute sirve para direccionar la pagina que necesitamos
                      Navigator.push(context, MaterialPageRoute(builder: (_)=> moneda()) );
                    },
                    child: Text('Cambio Moneda', style: TextStyle(color: Colors.white, fontSize: 20),
                    ),
                  ),
                ),
              ),
              Padding (padding: EdgeInsets.only(left: 20, top: 30, right: 10),
                child: Center(
                  child: ElevatedButton(
                    onPressed: (){
                      print('Boton Api Presionado');
                      // El materialpageroute sirve para direccionar la pagina que necesitamos
                      Navigator.push(context, MaterialPageRoute(builder: (_)=> rest()) );
                    },
                    child: Text('Api', style: TextStyle(color: Colors.white, fontSize: 20),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
