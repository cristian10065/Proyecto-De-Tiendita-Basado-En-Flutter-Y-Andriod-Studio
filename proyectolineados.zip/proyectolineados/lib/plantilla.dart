
import 'package:flutter/material.dart';
import 'package:proyectolineados/Vista/Geocalizacion.dart';

class Geocalizacion extends StatefulWidget{
  GeocalizacionApp createState() => GeocalizacionApp();
}
class GeocalizacionApp extends State<Geocalizacion>{
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Geolocalización'),

      ),
      body: SingleChildScrollView(),
    );
  }
}